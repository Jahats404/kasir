<?php

namespace App\Imports;

use App\Models\Barang;
use App\Models\JenisBarang;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class BarangImport implements ToModel, WithHeadingRow
{
    /**
     * Proses setiap baris data dari Excel.
     *
     * @param array $row
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        // Mencari id_jenis_barang berdasarkan nama jenis
        $jenisBarang = JenisBarang::where('nama_jenis', 'like', '%' . $row['jenis_barang'] . '%')->first();

        return new Barang([
            'id_barang' => 'B' . str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT), // ID Barang unik
            'nama_barang' => $row['nama_barang'], // Nama Barang
            'jb_id' => $jenisBarang ? $jenisBarang->id_jb : null, // ID Jenis Barang (null jika tidak ditemukan)
            'merk' => $row['merk'], // Merek Barang
            'stok' => $row['stok'], // Stok Barang
            'harga_beli' => $row['harga_beli'], // Harga Beli Barang
            'harga_jual' => $row['harga_jual'], // Harga Jual Barang
            'keterangan' => $row['keterangan'], // Keterangan Barang
        ]);
    }
}