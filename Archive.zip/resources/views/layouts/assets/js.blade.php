<script src="{{ asset('/') }}vendor/jquery/jquery.min.js"></script>
<script src="{{ asset('/') }}vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="{{ asset('/') }}vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="{{ asset('/') }}js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="{{ asset('/') }}vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="{{ asset('/') }}js/demo/chart-area-demo.js"></script>
<script src="{{ asset('/') }}js/demo/chart-pie-demo.js"></script>

<!-- Page level plugins -->
<script src="{{ asset('/') }}vendor/datatables/jquery.dataTables.min.js"></script>
<script src="{{ asset('/') }}vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/2.2.1/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/5.0.4/js/dataTables.fixedColumns.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/5.0.4/js/fixedColumns.dataTables.js"></script>
<script src="https://cdn.datatables.net/select/3.0.0/js/dataTables.select.js"></script>
<script src="https://cdn.datatables.net/select/3.0.0/js/select.dataTables.js"></script>


<!-- Page level custom scripts -->
<script src="{{ asset('/') }}js/demo/datatables-demo.js"></script>

{{-- <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script> --}}
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
{{-- <script>
    $(document).ready(function() {
        // Inisialisasi Select2 untuk dropdown yang diperlukan
        $('.js-example-basic-single').select2({
            placeholder: '-- Pilih --',
            allowClear: true,
            minimumInputLength: 1 // Set minimal karakter yang diperlukan untuk mulai mencari
        });
    });
</script> --}}